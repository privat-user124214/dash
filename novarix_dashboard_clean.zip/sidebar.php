<aside style="width: 200px; background: #1a1a1a; position: fixed; top: 0; left: 0; height: 100%; padding: 20px; color: white;">
    <h3>Navigation</h3>
    <ul style="list-style: none; padding-left: 0;">
        <li><a href="dashboard.php" style="color: white; text-decoration: none;">Dashboard</a></li>
        <li><a href="automod.php" style="color: white; text-decoration: none;">AutoMod</a></li>
        <li><a href="logout.php" style="color: white; text-decoration: none;">Logout</a></li>
    </ul>
</aside>
