<?php
$client_id = '1284484623279067196';
$client_secret = 'HIER_DEIN_CLIENT_SECRET'; // Ersetzen!
$redirect_uri = 'https://dash-k7s3.onrender.com/callback.php';
?>
